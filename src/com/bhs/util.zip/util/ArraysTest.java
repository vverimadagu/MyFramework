package com.bhs.util;

public class ArraysTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	int a[]={1,2,3,4};
	
	for(int i=0;i<a.length;i++){
		int mul=1;
		for(int j=0;j<a.length;j++){
			if(j!=i)
				mul*=a[j];
				
		}
		System.out.println(mul);
		//System.out.println("Multiply==="+multiply(i,a.length-1));
		
	}
	}
	
	private static int multiply(int index,int length){
		
		
		return length;
		
	}

}
